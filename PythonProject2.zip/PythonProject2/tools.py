from crewai_tools import tool
import json

# 模拟竞品数据库
MOCK_COMPETITORS = {
    "note_app": [
        {"name": "Notion", "price": "$10/month", "features": ["AI writing", "databases"]},
        {"name": "Obsidian", "price": "Free (sync $8/month)", "features": ["local-first", "graph view"]}
    ],
    "todo_app": [
        {"name": "Todoist", "price": "$5/month", "features": ["natural language", "Karma"]},
        {"name": "TickTick", "price": "$3/month", "features": ["Pomodoro", "calendar"]}
    ]
}

@tool("get_competitor_info")
def get_competitor_info(product_category: str) -> str:
    """获取某个产品类别的竞品基本信息（名称、价格、功能）。"""
    competitors = MOCK_COMPETITORS.get(product_category.lower(), [])
    if not competitors:
        return json.dumps({"message": "未找到相关竞品数据"})
    return json.dumps(competitors, ensure_ascii=False)

@tool("search_market_trends")
def search_market_trends(keywords: str) -> str:
    """模拟市场趋势搜索（返回假数据）"""
    # 实际中可接入 SerperDevTool 或 Google Trends
    return json.dumps({
        "keyword": keywords,
        "trend": "rising",
        "search_volume": "12,000/month",
        "related_terms": ["productivity", "collaboration", "AI assistant"]
    }, ensure_ascii=False)