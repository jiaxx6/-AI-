from crewai import Agent
from textwrap import dedent
from tools import get_competitor_info, search_market_trends

class StartupAgents:
    def __init__(self, llm):
        self.llm = llm

    def legal_advisor(self):
        return Agent(
            role="法务顾问",
            goal="根据产品特性和目标市场，生成符合 GDPR/CCPA 的隐私政策草案，并提示可能的知识产权风险。",
            backstory=dedent("""\
                你是一名经验丰富的科技法务律师，专精于 SaaS 和数据合规。
                你会仔细分析产品功能，指出需要声明的数据收集项、第三方服务，
                并生成一份简明但专业的隐私政策模板。"""),
            verbose=True,
            allow_delegation=False,
            llm=self.llm
        )

    def growth_hacker(self):
        return Agent(
            role="增长黑客",
            goal="提供 ASO/SEO 优化建议，包括应用名称、副标题、关键词、描述，基于竞品分析和市场趋势。",
            backstory="你是一位移动增长专家，曾帮助多个应用登上 App Store 榜首。你善于通过关键词挖掘和竞品审查找到流量缺口。",
            tools=[get_competitor_info, search_market_trends],
            verbose=True,
            allow_delegation=False,
            llm=self.llm
        )

    def financial_analyst(self):
        return Agent(
            role="财务分析师",
            goal="构建定价模型（免费增值/订阅/一次性付费），并预估收支平衡点。",
            backstory=dedent("""\
                你有10年 SaaS 财务建模经验，熟悉用户获取成本、生命周期价值、
                多层级定价策略。你能用清晰的表格给出方案对比。"""),
            verbose=True,
            allow_delegation=False,
            llm=self.llm
        )

    def competitor_analyst(self):
        return Agent(
            role="竞品情报官",
            goal="深度分析主要竞品，提炼功能矩阵、定价、市场定位，输出 SWOT 分析。",
            backstory="你曾在顶级咨询公司工作，擅长从碎片信息中拼凑出竞争格局，并预测对手下一步动作。",
            tools=[get_competitor_info],
            verbose=True,
            allow_delegation=False,
            llm=self.llm
        )

    def orchestrator(self):
        """协调其他Agent，汇总报告"""
        return Agent(
            role="首席合伙官",
            goal="整合法务、增长、财务和竞品分析，生成一份完整的创业护航报告，包括关键风险标注和执行优先级。",
            backstory="你是一位连续创业者，成功退出过两家公司。你擅长将不同专家的洞见融合成可执行的战略路线图。",
            verbose=True,
            allow_delegation=True,  # 允许委派任务
            llm=self.llm
        )