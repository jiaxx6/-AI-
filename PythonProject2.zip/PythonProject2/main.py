import os
from dotenv import load_dotenv
from crewai import Crew, Process
from agents import StartupAgents
from tasks import StartupTasks

load_dotenv()  # 加载 .env 中的 OPENAI_API_KEY 等

# 使用默认 OpenAI 模型，也可指定其他兼容模型
from langchain_openai import ChatOpenAI
llm = ChatOpenAI(model="gpt-4-turbo", temperature=0.3)

# 初始化
agents = StartupAgents(llm)

legal_agent = agents.legal_advisor()
growth_agent = agents.growth_hacker()
finance_agent = agents.financial_analyst()
competitor_agent = agents.competitor_analyst()
orchestrator = agents.orchestrator()

# 定义产品信息（你可以修改成你自己的）
product_name = "FocusFlow"
category = "todo_app"      # 会用于匹配竞品数据
target_market = "美国 + 欧洲（英语用户为主）"
features = ["AI 任务优先级推荐", "日历深度整合", "番茄钟", "跨设备实时同步"]

tasks_builder = StartupTasks(product_name, category, target_market, features)

# 创建四个子任务
legal_task = tasks_builder.legal_task(legal_agent)
growth_task = tasks_builder.growth_task(growth_agent)
finance_task = tasks_builder.finance_task(finance_agent)
competitor_task = tasks_builder.competitor_task(competitor_agent)

# 汇总任务，依赖前面四个
orchestrate_task = tasks_builder.orchestrate_task(
    orchestrator,
    context_tasks=[legal_task, growth_task, finance_task, competitor_task]
)

# 组装 Crew，使用层级流程让 orchestrator 可以委派任务
crew = Crew(
    agents=[legal_agent, growth_agent, finance_agent, competitor_agent, orchestrator],
    tasks=[legal_task, growth_task, finance_task, competitor_task, orchestrate_task],
    process=Process.hierarchical,  # 管理者自动协调
    manager_llm=llm,
    verbose=True
)

if __name__ == "__main__":
    result = crew.kickoff()
    print("\n\n================== 最终《创业护航手册》 ==================")
    print(result)