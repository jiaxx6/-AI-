from crewai import Task
from textwrap import dedent

class StartupTasks:
    def __init__(self, product_name, category, target_market, features):
        self.product_name = product_name
        self.category = category
        self.target_market = target_market
        self.features = features

    def legal_task(self, agent):
        return Task(
            description=dedent(f"""\
                为产品 "{self.product_name}" 生成隐私政策草案。
                产品类别：{self.category}
                目标市场：{self.target_market}
                功能列表：{self.features}
                请特别关注：是否需要GDPR代表、Cookie同意机制、数据存储位置声明。"""),
            expected_output="一份结构化的隐私政策文档，Markdown格式，包含：概述、收集的数据类型、使用目的、第三方共享、用户权利、联系方式。",
            agent=agent
        )

    def growth_task(self, agent):
        return Task(
            description=dedent(f"""\
                为 "{self.product_name}" 制定应用商店优化(ASO)方案。
                类别：{self.category}
                目标市场：{self.target_market}
                首先调用 get_competitor_info({self.category}) 获取竞品列表，
                然后调用 search_market_trends({self.category}) 获取趋势，
                最后输出：推荐应用名称、副标题、关键词集（英语+中文）、简短描述和完整描述。"""),
            expected_output="一份ASO优化方案，包含5个候选应用名、30个关键词、以及App Store和Google Play的完整描述文本。",
            agent=agent
        )

    def finance_task(self, agent):
        return Task(
            description=dedent(f"""\
                为 "{self.product_name}" 设计定价策略。
                假设：目标用户获取成本 CAC=$5，期望月活5000人，转化率3%。
                请给出至少两种定价模型（如免费+广告、订阅、一次买断）的盈亏点分析，
                并推荐最适合早期创业阶段的方案。"""),
            expected_output="一份财务分析报告，包含：定价方案对比表、盈亏分析、推荐方案及理由。",
            agent=agent
        )

    def competitor_task(self, agent):
        return Task(
            description=dedent(f"""\
                利用 get_competitor_info({self.category}) 获取的数据，
                对主要竞品进行深度分析。输出每个竞品的SWOT分析（优势、劣势、机会、威胁），
                并总结 "{self.product_name}" 相对于它们的差异化可能。"""),
            expected_output="竞品SWOT分析表及差异化战略建议。",
            agent=agent
        )

    def orchestrate_task(self, agent, context_tasks):
        """最终汇总任务，依赖前面四个子任务的结果"""
        return Task(
            description=dedent(f"""\
                你是首席合伙官。下面有四份来自不同专家的报告：
                - 法务顾问的隐私政策草案
                - 增长黑客的ASO方案
                - 财务分析师的定价模型
                - 竞品情报官的竞争分析
                请综合这些报告，生成一份最终版《创业护航手册》，要求：
                1）执行摘要
                2）关键发现（按优先级排序）
                3）风险清单（红色/黄色标注）
                4）下一步行动（本周/本月/本季度）"""),
            expected_output="一份完整的《创业护航手册》，Markdown格式，排版专业，可直接提供给创始人审阅。",
            agent=agent,
            context=context_tasks  # 传递依赖关系
        )